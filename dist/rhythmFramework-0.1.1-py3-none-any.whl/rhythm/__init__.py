"""A Framework for faster development with AI Agents.
Exports only the base Robot agent."""

from .robot import Robot, tool